﻿namespace Trinity.Framework.Avoidance.Structures
{
    public enum RayType
    {
        None = 0,
        Cast,
        Walk,
    }
}