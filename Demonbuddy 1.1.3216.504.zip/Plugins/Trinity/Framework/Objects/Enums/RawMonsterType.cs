﻿namespace Trinity.Framework.Objects.Enums
{
    internal class RawMonsterType
    {
        public enum Name
        {
            BloodGolem = 408833060,
            KnockbackPrefix004 = -2108150615,
            Undead = 418031985,
            Demon = 122344211,
            Beast = 119959439,
            Human = 127662425,
            Breakable = 364480921,
            Scenery = -2101757351,
            Ally = 3607186,
            Team = 4281991,
            Helper = -101101792,
            CorruptedAngel = -1343937537,
            Pandemonium = -1663892291,
        }
    }
}