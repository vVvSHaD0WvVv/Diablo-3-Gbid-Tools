﻿namespace Trinity.Framework.Objects.Enums
{
    public enum TeamType
    {
        None = 0,
        Player = 2,
        Monsters = 10,
    }
}