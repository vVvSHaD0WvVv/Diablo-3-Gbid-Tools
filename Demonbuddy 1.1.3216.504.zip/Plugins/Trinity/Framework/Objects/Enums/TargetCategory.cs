﻿namespace Trinity.Framework.Objects.Enums
{
    public enum TargetCategory
    {
        None = 0,
        Priority,
        Normal,
        Ignore
    }
}