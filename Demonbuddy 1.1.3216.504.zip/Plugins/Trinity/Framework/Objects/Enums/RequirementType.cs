namespace Trinity.Framework.Objects.Memory
{
    public enum RequirementType
    {
        None = -1,
        EquipItem = 57,
    }
}