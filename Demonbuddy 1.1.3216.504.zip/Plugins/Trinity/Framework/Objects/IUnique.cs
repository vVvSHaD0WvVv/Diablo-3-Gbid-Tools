﻿namespace Trinity.Framework.Objects
{
    public interface IUnique
    {
        int Id { get; }
    }
}