﻿namespace Trinity.Components.Adventurer.Coroutines
{
    public enum CoroutineResult
    {
        Success,
        Failure
    }
}