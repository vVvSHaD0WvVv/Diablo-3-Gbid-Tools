﻿namespace Trinity.Components.Adventurer.Game.Rift
{
    public enum RiftStep
    {
        NotStarted,
        KillingMobs,
        BossSpawned,
        UrshiSpawned,
        Cleared,
        Completed
    }
}