namespace Trinity.Components.Adventurer.Game.Exploration.SceneMapping
{
    public enum GateSide
    {
        None = 0,
        DeepSide,
        ShallowSide,
    }
}