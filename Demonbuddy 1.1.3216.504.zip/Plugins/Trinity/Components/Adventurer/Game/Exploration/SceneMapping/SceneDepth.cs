namespace Trinity.Components.Adventurer.Game.Exploration.SceneMapping
{
    public enum SceneDepth
    {
        None = 0,
        Deeper,
        Shallower,
        NotFound,
        Same
    }
}