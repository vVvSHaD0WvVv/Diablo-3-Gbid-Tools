namespace Trinity.Components.Adventurer.Game.Exploration.SceneMapping
{
    public enum DeathGateType
    {
        None = 0,
        ExitSequence,
        EnterSequence
    }
}