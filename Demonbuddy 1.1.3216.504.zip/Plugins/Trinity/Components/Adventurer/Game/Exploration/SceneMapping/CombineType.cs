namespace Trinity.Components.Adventurer.Game.Exploration.SceneMapping
{
    public enum CombineType
    {
        None = 0,
        Add,
        Subtract,
    }
}