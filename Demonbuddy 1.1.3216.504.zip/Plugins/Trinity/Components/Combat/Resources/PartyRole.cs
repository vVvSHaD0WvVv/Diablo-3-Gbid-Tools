namespace Trinity.Components.Combat.Resources
{
    public enum PartyRole
    {
        None = 0,
        Follower,
        Leader,
        Puller,
    }
}