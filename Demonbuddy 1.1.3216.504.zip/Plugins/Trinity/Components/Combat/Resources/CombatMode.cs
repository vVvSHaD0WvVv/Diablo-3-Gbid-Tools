﻿namespace Trinity.Components.Combat.Resources
{
    public enum CombatMode
    {
        Normal,
        Off,
        KillAll,
        SafeZerg,
    }
}