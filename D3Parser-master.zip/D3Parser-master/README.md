D3Parser
========

*.gam and *.stl files parser for Diablo 3