Created by: ooCONTAGIONoo
>>>Re-Done By: V-TheDevilsSon_V<<<

Summary:

This tool allows you to compare two lists of GBIDs and will update the old list with the new items when completed. 

Directions: 

Select a source file. The source file will be a file containing a list of new GBIDs. (If using the D3HashTool, the source file will be the new file that was created.) 

Select a target file. This will be the existing list of GBIDs the editor is currently using. Typically the file is named "ENGBID".

Click the compare files button. This will begin the comparison of the two files. When complete, an updated file will be generated and placed in the D3_GBIDS folder.

Replace the old "ENGBID" file with the new file that was generated. (If the new file is not named ENGBID, you must rename it so the editor will read it)

Restart the editor and test.

The new items will be located in the "New Items" drop down inside the editor.
 
Enjoy!

Any questions or issues, please email me @ : kompletekontrolgaming@gmail.com