﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace D3Helper.A_Enums
{
    public class Powers
    {
        public const int InTownBuff = 220304;
        public const int DrinkHealthPotion = 30211;
        public const int RessurectPlayer = 30021;
        public const int UseStoneOfRecall = 191590;
        public const int UseDungeonStoneOfRecall = 220318;
        public const int TeleportToWaypoint = 349060;
        public const int TeleportToPlayer_1 = 371139;
        public const int TeleportToPlayer_2 = 318242;
        public const int Convention_PowerSno = 430674;
    }
}
