﻿namespace D3Helper
{
    partial class Window_Main
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Window_Main));
            this.bt_Skill1 = new System.Windows.Forms.Button();
            this.bt_Skill2 = new System.Windows.Forms.Button();
            this.bt_Skill3 = new System.Windows.Forms.Button();
            this.bt_Skill4 = new System.Windows.Forms.Button();
            this.btn_info = new System.Windows.Forms.Button();
            this.btn_settings = new System.Windows.Forms.Button();
            this.lb_versionlb = new System.Windows.Forms.Label();
            this.btn_changelog = new System.Windows.Forms.Button();
            this.bt_update = new System.Windows.Forms.Button();
            this.bt_SkillRmb = new System.Windows.Forms.Button();
            this.bt_SkillLmb = new System.Windows.Forms.Button();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.BTN_Forum = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.comboBox_simplecast = new System.Windows.Forms.ComboBox();
            this.checkBox_simpleCast = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // bt_Skill1
            // 
            this.bt_Skill1.BackColor = System.Drawing.Color.Transparent;
            this.bt_Skill1.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.bt_Skill1.FlatAppearance.BorderSize = 0;
            this.bt_Skill1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt_Skill1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_Skill1.ForeColor = System.Drawing.Color.Transparent;
            this.bt_Skill1.Location = new System.Drawing.Point(13, 13);
            this.bt_Skill1.Name = "bt_Skill1";
            this.bt_Skill1.Size = new System.Drawing.Size(75, 74);
            this.bt_Skill1.TabIndex = 0;
            this.bt_Skill1.UseVisualStyleBackColor = false;
            this.bt_Skill1.Click += new System.EventHandler(this.bt_Skill1_Click);
            // 
            // bt_Skill2
            // 
            this.bt_Skill2.BackColor = System.Drawing.Color.Transparent;
            this.bt_Skill2.FlatAppearance.BorderSize = 0;
            this.bt_Skill2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt_Skill2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_Skill2.ForeColor = System.Drawing.Color.Transparent;
            this.bt_Skill2.Location = new System.Drawing.Point(94, 13);
            this.bt_Skill2.Name = "bt_Skill2";
            this.bt_Skill2.Size = new System.Drawing.Size(75, 74);
            this.bt_Skill2.TabIndex = 1;
            this.bt_Skill2.UseVisualStyleBackColor = false;
            this.bt_Skill2.Click += new System.EventHandler(this.bt_Skill2_Click);
            // 
            // bt_Skill3
            // 
            this.bt_Skill3.BackColor = System.Drawing.Color.Transparent;
            this.bt_Skill3.FlatAppearance.BorderSize = 0;
            this.bt_Skill3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt_Skill3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_Skill3.ForeColor = System.Drawing.Color.Transparent;
            this.bt_Skill3.Location = new System.Drawing.Point(175, 13);
            this.bt_Skill3.Name = "bt_Skill3";
            this.bt_Skill3.Size = new System.Drawing.Size(75, 74);
            this.bt_Skill3.TabIndex = 2;
            this.bt_Skill3.UseVisualStyleBackColor = false;
            this.bt_Skill3.Click += new System.EventHandler(this.bt_Skill3_Click);
            // 
            // bt_Skill4
            // 
            this.bt_Skill4.BackColor = System.Drawing.Color.Transparent;
            this.bt_Skill4.FlatAppearance.BorderSize = 0;
            this.bt_Skill4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt_Skill4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_Skill4.ForeColor = System.Drawing.Color.Transparent;
            this.bt_Skill4.Location = new System.Drawing.Point(256, 13);
            this.bt_Skill4.Name = "bt_Skill4";
            this.bt_Skill4.Size = new System.Drawing.Size(75, 74);
            this.bt_Skill4.TabIndex = 3;
            this.bt_Skill4.UseVisualStyleBackColor = false;
            this.bt_Skill4.Click += new System.EventHandler(this.bt_Skill4_Click);
            // 
            // btn_info
            // 
            this.btn_info.BackColor = System.Drawing.Color.Transparent;
            this.btn_info.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btn_info.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btn_info.FlatAppearance.BorderSize = 0;
            this.btn_info.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btn_info.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btn_info.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_info.ForeColor = System.Drawing.Color.Transparent;
            this.btn_info.Location = new System.Drawing.Point(866, 34);
            this.btn_info.Name = "btn_info";
            this.btn_info.Size = new System.Drawing.Size(25, 25);
            this.btn_info.TabIndex = 4;
            this.toolTip1.SetToolTip(this.btn_info, "Info");
            this.btn_info.UseVisualStyleBackColor = false;
            this.btn_info.Click += new System.EventHandler(this.button1_Click);
            // 
            // btn_settings
            // 
            this.btn_settings.BackColor = System.Drawing.Color.Transparent;
            this.btn_settings.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btn_settings.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btn_settings.FlatAppearance.BorderSize = 0;
            this.btn_settings.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btn_settings.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btn_settings.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_settings.Location = new System.Drawing.Point(866, 3);
            this.btn_settings.Name = "btn_settings";
            this.btn_settings.Size = new System.Drawing.Size(25, 25);
            this.btn_settings.TabIndex = 6;
            this.toolTip1.SetToolTip(this.btn_settings, "Settings");
            this.btn_settings.UseVisualStyleBackColor = false;
            this.btn_settings.Click += new System.EventHandler(this.bt_hotkeys_Click);
            // 
            // lb_versionlb
            // 
            this.lb_versionlb.AutoSize = true;
            this.lb_versionlb.BackColor = System.Drawing.Color.Transparent;
            this.lb_versionlb.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_versionlb.ForeColor = System.Drawing.Color.Red;
            this.lb_versionlb.Location = new System.Drawing.Point(506, 9);
            this.lb_versionlb.Name = "lb_versionlb";
            this.lb_versionlb.Size = new System.Drawing.Size(138, 13);
            this.lb_versionlb.TabIndex = 7;
            this.lb_versionlb.Text = "New Version Available!";
            this.lb_versionlb.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // btn_changelog
            // 
            this.btn_changelog.Location = new System.Drawing.Point(735, 68);
            this.btn_changelog.Name = "btn_changelog";
            this.btn_changelog.Size = new System.Drawing.Size(75, 23);
            this.btn_changelog.TabIndex = 8;
            this.btn_changelog.Text = "Changelog";
            this.btn_changelog.UseVisualStyleBackColor = true;
            this.btn_changelog.Click += new System.EventHandler(this.button2_Click);
            // 
            // bt_update
            // 
            this.bt_update.Location = new System.Drawing.Point(569, 33);
            this.bt_update.Name = "bt_update";
            this.bt_update.Size = new System.Drawing.Size(75, 23);
            this.bt_update.TabIndex = 9;
            this.bt_update.Text = "Update";
            this.bt_update.UseVisualStyleBackColor = true;
            this.bt_update.Click += new System.EventHandler(this.bt_update_Click);
            // 
            // bt_SkillRmb
            // 
            this.bt_SkillRmb.BackColor = System.Drawing.Color.Transparent;
            this.bt_SkillRmb.FlatAppearance.BorderSize = 0;
            this.bt_SkillRmb.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt_SkillRmb.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_SkillRmb.ForeColor = System.Drawing.Color.Transparent;
            this.bt_SkillRmb.Location = new System.Drawing.Point(458, 13);
            this.bt_SkillRmb.Name = "bt_SkillRmb";
            this.bt_SkillRmb.Size = new System.Drawing.Size(75, 74);
            this.bt_SkillRmb.TabIndex = 10;
            this.bt_SkillRmb.UseVisualStyleBackColor = false;
            this.bt_SkillRmb.Click += new System.EventHandler(this.bt_SkillRmb_Click);
            // 
            // bt_SkillLmb
            // 
            this.bt_SkillLmb.BackColor = System.Drawing.Color.Transparent;
            this.bt_SkillLmb.FlatAppearance.BorderSize = 0;
            this.bt_SkillLmb.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt_SkillLmb.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_SkillLmb.ForeColor = System.Drawing.Color.Transparent;
            this.bt_SkillLmb.Location = new System.Drawing.Point(377, 13);
            this.bt_SkillLmb.Name = "bt_SkillLmb";
            this.bt_SkillLmb.Size = new System.Drawing.Size(75, 74);
            this.bt_SkillLmb.TabIndex = 14;
            this.bt_SkillLmb.UseVisualStyleBackColor = false;
            this.bt_SkillLmb.Click += new System.EventHandler(this.bt_SkillLmb_Click);
            // 
            // BTN_Forum
            // 
            this.BTN_Forum.Location = new System.Drawing.Point(816, 68);
            this.BTN_Forum.Name = "BTN_Forum";
            this.BTN_Forum.Size = new System.Drawing.Size(75, 23);
            this.BTN_Forum.TabIndex = 15;
            this.BTN_Forum.Text = "Forum";
            this.BTN_Forum.UseVisualStyleBackColor = true;
            this.BTN_Forum.Click += new System.EventHandler(this.BTN_Forum_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(654, 68);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 16;
            this.button1.Text = "Skill Editor";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // comboBox_simplecast
            // 
            this.comboBox_simplecast.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_simplecast.FormattingEnabled = true;
            this.comboBox_simplecast.Location = new System.Drawing.Point(654, 37);
            this.comboBox_simplecast.Name = "comboBox_simplecast";
            this.comboBox_simplecast.Size = new System.Drawing.Size(237, 21);
            this.comboBox_simplecast.TabIndex = 17;
            this.comboBox_simplecast.SelectedIndexChanged += new System.EventHandler(this.comboBox_simplecast_SelectedIndexChanged);
            // 
            // checkBox_simpleCast
            // 
            this.checkBox_simpleCast.AutoSize = true;
            this.checkBox_simpleCast.Location = new System.Drawing.Point(654, 14);
            this.checkBox_simpleCast.Name = "checkBox_simpleCast";
            this.checkBox_simpleCast.Size = new System.Drawing.Size(114, 17);
            this.checkBox_simpleCast.TabIndex = 18;
            this.checkBox_simpleCast.Text = "Enable SimpleCast";
            this.checkBox_simpleCast.UseVisualStyleBackColor = true;
            this.checkBox_simpleCast.CheckedChanged += new System.EventHandler(this.checkBox_simpleCast_CheckedChanged);
            // 
            // Window_Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.BackgroundImage = global::D3Helper.Properties.Resources.Background_Monk_50_MainWindow;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(903, 102);
            this.Controls.Add(this.checkBox_simpleCast);
            this.Controls.Add(this.comboBox_simplecast);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.BTN_Forum);
            this.Controls.Add(this.bt_SkillLmb);
            this.Controls.Add(this.bt_SkillRmb);
            this.Controls.Add(this.bt_update);
            this.Controls.Add(this.btn_changelog);
            this.Controls.Add(this.lb_versionlb);
            this.Controls.Add(this.btn_settings);
            this.Controls.Add(this.btn_info);
            this.Controls.Add(this.bt_Skill4);
            this.Controls.Add(this.bt_Skill3);
            this.Controls.Add(this.bt_Skill2);
            this.Controls.Add(this.bt_Skill1);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Window_Main";
            this.Text = "D3 Helper - Auto Skill/Buff Manager";
            this.Load += new System.EventHandler(this.Window_Main_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bt_Skill1;
        private System.Windows.Forms.Button bt_Skill2;
        private System.Windows.Forms.Button bt_Skill3;
        private System.Windows.Forms.Button bt_Skill4;
        private System.Windows.Forms.Button btn_info;
        private System.Windows.Forms.Button btn_settings;
        private System.Windows.Forms.Label lb_versionlb;
        private System.Windows.Forms.Button btn_changelog;
        private System.Windows.Forms.Button bt_update;
        private System.Windows.Forms.Button bt_SkillRmb;
        private System.Windows.Forms.Button bt_SkillLmb;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Button BTN_Forum;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox comboBox_simplecast;
        private System.Windows.Forms.CheckBox checkBox_simpleCast;
    }
}

