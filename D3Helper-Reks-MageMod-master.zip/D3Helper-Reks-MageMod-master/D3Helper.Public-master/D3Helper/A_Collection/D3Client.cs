﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace D3Helper.A_Collection
{
    class D3Client
    {
        public class Window
        {
            public static bool isForeground;                                // default: false
            public static Int32Rect D3ClientRect;                    
        }
    }
}
