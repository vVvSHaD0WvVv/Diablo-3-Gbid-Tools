﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using D3Helper.A_Enums;

namespace D3Helper.A_Collection
{
    class SkillCastConditions
    {
        
        public class Custom
        {
            public static List<SkillData> CustomDefinitions = new List<SkillData>();
        }
    }
}
