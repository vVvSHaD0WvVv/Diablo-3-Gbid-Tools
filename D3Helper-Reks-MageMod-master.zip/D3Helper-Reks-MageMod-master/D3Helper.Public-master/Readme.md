###### Enigma.D3 needs to be referenced
https://github.com/Enigma32/Enigma.D3


---

###### Credits to Enigma for his awesome framework <3

[Enigma Framework Forum Link](http://www.ownedcore.com/forums/diablo-3/diablo-3-bots-programs/diablo-3-memory-editing/469521-c-enigma-d3.html)

---

###### Donate for Enigma Framework
[![Donate](https://img.shields.io/badge/Donate-PayPal-green.svg)](https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=UZXUSKXRWSWSC)
