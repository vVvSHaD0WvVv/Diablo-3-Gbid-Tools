﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Enigma.D3.Win32
{
	public struct Handle
	{
		public int Value;
	}
}
