using Enigma.Memory;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Enigma.D3.Graphics
{
	[Flags]
	public enum DisplayModeFlags : int
	{
		VerticalSync = 4,
		Unknown8 = 8
	}
}
